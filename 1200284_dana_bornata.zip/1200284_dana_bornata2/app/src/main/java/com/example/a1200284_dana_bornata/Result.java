package com.example.a1200284_dana_bornata;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Result extends AppCompatActivity {
    private TextView feedbackTextView;
    private TextView scoreTextView;
    private Button resetButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);

        feedbackTextView = findViewById(R.id.feedbackTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        resetButton = findViewById(R.id.resetButton);

        Intent intent = getIntent();
        int userScore = intent.getIntExtra("userScore", 0);
        String resultText = intent.getStringExtra("resultText");

        displayResult(userScore, resultText);

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetGame();
            }
        });
    }


    private void displayResult(int userScore, String resultText) {
        String feedback = (userScore >= 4) ? "You Won!" : "You Lost!";
        feedbackTextView.setText(feedback);
        scoreTextView.setText(resultText);
    }

    private void resetGame() {
        Intent intent = new Intent(Result.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
