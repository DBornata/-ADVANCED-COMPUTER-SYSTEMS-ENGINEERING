package com.example.a1200284_dana_bornata;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<String> Questions;
    private List<Integer> Answers;
    private int currentQuestionIndex;
    private int Score;
    private CountDownTimer decreaseCounter;
    private TextView decreaseCounterTextView;
    private TextView scoreTextView;

    private TextView questionTextView;
    private Button Choise1;
    private Button Choise2;
    private Button Choise3;
    private Button Choise4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeViews();
        initializeQuestions();
        Start();
    }
    private void initializeQuestions() {
        Questions = new ArrayList<>();
        Questions.add("السؤال الأول: من هو المقاتل الأنيق رحمه الله ؟#المتخاذل محمود عباس#المتخاذل عبد الله الثاني بن الحسين #حمزة عامر رحمه الله #المتخاذل عبدالفتاح السيسي #3");
        Questions.add("السؤال الثاني:ما هو تاريخ طوفان الاقصى ؟#17 اكتوبر#15نوفمبر#10 ديسمبر#7اكتوبر#3");
        Questions.add("السؤال الثالث:من هو ابو الذينين؟#ترامب لعنه الله #دانييل هاغاري لعنه الله #افيخاي لعنه الله #بايدن لعنه الله #4");
        Questions.add("السؤال الرابع :ما هي الطبخة المفضلة للمتخاذل عبدالله ؟#منسف#مقلوبة#بيذنجان#قلي بندورة#2");
        Questions.add("السؤال الخامس:ما اكثر مساعدات الدول العربية لغزة الصمود الحبيبة ؟#اسلحة#طائرات#اكفان#طعام#1");
        Answers = new ArrayList<>();
        Answers.add(3);
        Answers.add(4);
        Answers.add(2);
        Answers.add(4);
        Answers.add(3);
    }


    private void initializeViews() {
        decreaseCounterTextView = findViewById(R.id.secondsLeftTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        questionTextView = findViewById(R.id.questionTextView);
        Choise1 = findViewById(R.id.choiceButton1);
        Choise2 = findViewById(R.id.choiceButton2);
        Choise3 = findViewById(R.id.choiceButton3);
        Choise4 = findViewById(R.id.choiceButton4);
    }

    private void showNextQuestion() {
        String currentQuestion = Questions.get(currentQuestionIndex);
        String[] questionParts = currentQuestion.split("#");
        questionTextView.setText(questionParts[0]);

        Choise1.setText(questionParts[1]);
        Choise2.setText(questionParts[2]);
        Choise3.setText(questionParts[3]);
        Choise4.setText(questionParts[4]);


        setChoiceButtonClickListeners();
    }


    private void Start() {
        showNextQuestion();
        startCountdownTimer();
    }


    private void setChoiceButtonClickListeners() {
        Choise1.setOnClickListener(view -> handleUserAnswer(1));
        Choise2.setOnClickListener(view -> handleUserAnswer(2));
        Choise3.setOnClickListener(view -> handleUserAnswer(3));
        Choise4.setOnClickListener(view -> handleUserAnswer(4));
    }

    private void handleUserAnswer(int userChoice) {
        if (userChoice == Answers.get(currentQuestionIndex)) {
            Score++;
            updateScoreTextView();
        }
        moveToNextQuestion();
    }

    private void updateScoreTextView() {
        scoreTextView.setText("Score: " + Score);
    }

    private void moveToNextQuestion() {
        if (currentQuestionIndex < Questions.size() - 1) {
            currentQuestionIndex++;
            showNextQuestion();
            resetCountdownTimer();
        } else {
            showResultActivity();
        }
    }

    private void startCountdownTimer() {
        decreaseCounter = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                decreaseCounterTextView.setText(String.valueOf(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                moveToNextQuestion();
            }
        }.start();
    }

    private void resetCountdownTimer() {
        if (decreaseCounter != null) {
            decreaseCounter.cancel();
        }
        startCountdownTimer();
    }

    private void showResultActivity() {
        if (decreaseCounter != null) {
            decreaseCounter.cancel();
        }

        int totalQuestions = Questions.size();
        String resultText = Score + "/" + totalQuestions;

        Intent intent = new Intent(MainActivity.this, Result.class);
        intent.putExtra("userScore", Score);
        intent.putExtra("resultText", resultText);

        startActivity(intent);
        finish();
    }
}
