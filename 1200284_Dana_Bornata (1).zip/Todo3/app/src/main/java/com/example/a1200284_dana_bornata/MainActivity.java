package com.example.a1200284_dana_bornata;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private ImageView sun, cloud1, cloud2, car, trafficLight, rock;
    private Handler handler = new Handler();
    private int currentLight = -1; // 0: Red, 1: Yellow, 2: Green
    private final int[] lightDrawableIds = {R.drawable.red, R.drawable.prange, R.drawable.green};
    private Animation carRotateAnimation;
    private long startTime; // Variable to store the start time
    private long originalCarAnimationDuration = 3200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Load animations
        Animation sunAnimation = AnimationUtils.loadAnimation(this, R.anim.sun_animation);
        Animation carAnimation = AnimationUtils.loadAnimation(this, R.anim.car_animation);
        Animation cloud1Animation = AnimationUtils.loadAnimation(this, R.anim.cloud1_animation);
        Animation cloud2Animation = AnimationUtils.loadAnimation(this, R.anim.cloud2_animation);
        Animation rockAnimation = AnimationUtils.loadAnimation(this, R.anim.rouck_animation);
        carRotateAnimation = AnimationUtils.loadAnimation(this, R.anim.car_animation);

        // Apply animations to ImageViews
        sun = findViewById(R.id.sun);
        car = findViewById(R.id.car);
        cloud1 = findViewById(R.id.cloud1);
        cloud2 = findViewById(R.id.cloud2);
        rock = findViewById(R.id.rock);
        trafficLight = findViewById(R.id.red);

        sun.startAnimation(sunAnimation);
        car.startAnimation(carAnimation);
        cloud1.startAnimation(cloud1Animation);
        cloud2.startAnimation(cloud2Animation);
        rock.startAnimation(rockAnimation);

        // Set the start time
        startTime = System.currentTimeMillis();

        manageTrafficLights();
    }

    private void manageTrafficLights() {
        final Runnable changeLight = new Runnable() {
            @Override
            public void run() {
                // Change the traffic light color.
                currentLight = (currentLight + 1) % lightDrawableIds.length;
                trafficLight.setImageResource(lightDrawableIds[currentLight]);

                // Start or stop the car animation based on the traffic light color.
                if (currentLight == 0) { // Red light
                    car.clearAnimation(); // Stop car rotation
                } else { // Yellow or green light
                    // Check if the traffic light is green
                    if (currentLight == 2) {
                        // Start car rotation animation
                        car.startAnimation(carRotateAnimation);
                    } else {
                        // Stop car rotation animation if it's not green
                        car.clearAnimation();
                    }
                }

                // Determine the next change delay based on the current light state.
                long delay = currentLight == 0 ? 3000 : (currentLight == 1 ? 2000 : 5000);

                // Calculate the elapsed time since the start of the program
                long currentTime = System.currentTimeMillis();
                long elapsedTime = currentTime - startTime;

                if (elapsedTime >= 9500) {
                    // Decrease car animation speed to half if 9 seconds have elapsed
                    carRotateAnimation.setDuration(originalCarAnimationDuration * 2);
                } else {
                    // Reset car animation speed to original
                    carRotateAnimation.setDuration(originalCarAnimationDuration);
                }

                if (isCollision(car, rock)) {
                    // Decrease car animation speed if there's a collision
                    carRotateAnimation.setDuration(originalCarAnimationDuration * 2);
                } else {
                    // Reset car animation speed to original
                    carRotateAnimation.setDuration(originalCarAnimationDuration);
                }

                // Schedule the next change after the delay.
                handler.postDelayed(this, delay + 1000);
            }
        };
        handler.post(changeLight); // Start the traffic light change cycle.
    }

    // Collision detection method
    private boolean isCollision(ImageView car, ImageView rock) {

        return car.getX() < rock.getX() + rock.getWidth() &&
                car.getX() + car.getWidth() > rock.getX() &&
                car.getY() < rock.getY() + rock.getHeight() &&
                car.getY() + car.getHeight() > rock.getY();
    }
}
